# Panduan menaruh dua proyek di GitHub Pages

1. Buat akun di github.com (gratis). Nama pengguna akan menjadi bagian alamat, misalnya `nadiaaulia`.
2. Klik New repository, beri nama `portfolio`, pilih Public, lalu Create.
3. Klik "uploading an existing file", seret folder `analisis-tata-kelola-it` dan `suara-kampus-kahayan-project` dari ZIP ini, lalu Commit changes.
4. Buka Settings > Pages. Pada Branch pilih `main` dan folder `/ (root)`, lalu Save.
5. Tunggu 1-2 menit. Alamat akhirnya:
   - https://NAMAPENGGUNA.github.io/portfolio/analisis-tata-kelola-it/
   - https://NAMAPENGGUNA.github.io/portfolio/suara-kampus-kahayan-project/

Catatan: kedua halaman memuat keterangan "dibuat dengan bantuan AI" di bagian bawah. Biarkan keterangan itu supaya portofolio jujur.

Cara belajar kodenya: buka `index.html` di Notepad atau VS Code. Bagian `<style>` mengatur tampilan, bagian `<script>` mengatur isi dan interaksi. Coba ubah teks artikel atau skor indikator, simpan, lalu buka file di browser.
